﻿using System.Windows;
using System.Windows.Controls;

namespace Demo.Lib
{
    public class TestControl : Control
    {
        static TestControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TestControl), new FrameworkPropertyMetadata(typeof(TestControl)));
        }
    }
}
